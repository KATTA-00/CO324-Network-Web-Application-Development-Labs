# import modules
from urllib import request

# GET request 
response = request.urlopen("https://ta.wikipedia.org/wiki/%E0%AE%9A%E0%AE%BF%E0%AE%99%E0%AF%8D%E0%AE%95%E0%AE%B3%E0%AE%AE%E0%AF%8D")

body = response.read()

# print the body
print(body.decode("utf-8"))

response.close()